package com.example.polytechnicshiksha;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class electure extends AppCompatActivity {
    public static String url;
    public static String title;
    //private Object Spinner;
   // String item;
    List<Hero> heroList;
    List<String> categories = new ArrayList<String>();
    List<String> branchlist = new ArrayList<>();
    List<String> sublist = new ArrayList<>();
    List<String> unitlist = new ArrayList<>();
    EditText etSearch;
    Button btnSearch;
    ListView lvVideo;
    ArrayList<VideoDetails> videoDetailsArrayList;
    MyListAdapter customListAdapter;
    String searchName;
    String item1;
    String item2;
    String item3;
    String item4;
    String item5;

    ArrayAdapter<CharSequence> adapter;
    ArrayAdapter<String> secondAdapter ;
    ArrayAdapter<String> thirdAdapter ;
    ArrayAdapter<String> forthAdapter ;
    ArrayAdapter<String> fifthAdapter ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_electure);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle("E-Lectures");
        btnSearch = (Button) findViewById(R.id.electbtngo);

        Spinner spinner1 = (Spinner) findViewById(R.id.spinner_elect_course);
        Spinner spinner2 = (Spinner) findViewById(R.id.spinner_elect_year);
        Spinner spinner3 = (Spinner) findViewById(R.id.spinner_elect_branch);
        Spinner spinner4 = (Spinner) findViewById(R.id.spinner_elect_subcode);
        Spinner spinner5 = (Spinner) findViewById(R.id.spinner_elect_unit);

        adapter = ArrayAdapter.createFromResource(this,R.array.labmanual_array, android.R.layout.simple_spinner_dropdown_item);
        secondAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        thirdAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, branchlist);
        forthAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, sublist);
        fifthAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, unitlist);

        spinner2.setEnabled(false);
        spinner3.setEnabled(false);
        spinner4.setEnabled(false);
        spinner5.setEnabled(false);
        btnSearch.setEnabled(false);

        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {

                item1 = parent.getItemAtPosition(pos).toString();
                if (item1.matches("Engineering"))
                {
                   spinner2.setEnabled(true);
                    categories.clear();
                    categories.add("Select Year/Semester");

                    categories.add("First Semester");
                    categories.add("Second Semester");
                    categories.add("Second Year");
                    categories.add("Third Year");
                }
                else
                {
                    categories.clear();
                    categories.add("Select Year/Semester");

                    branchlist.clear();
                    branchlist.add("Select Branch");

                    sublist.clear();
                    sublist.add("Select Subject");

                    unitlist.clear();
                    unitlist.add("Select Unit");

                    secondAdapter.notifyDataSetChanged();
                    thirdAdapter.notifyDataSetChanged();
                    forthAdapter.notifyDataSetChanged();
                    fifthAdapter.notifyDataSetChanged();

                    spinner2.setEnabled(false);
                    spinner2.setPrompt("Select Year/Semester");
                    spinner3.setEnabled(false);
                    spinner3.setPrompt("Select Branch");
                    spinner4.setEnabled(false);
                    spinner4.setPrompt("Select Subject");
                    spinner5.setEnabled(false);
                    spinner5.setPrompt("Select Unit");
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });
        adapter.setDropDownViewResource(android.R.layout.select_dialog_item);
        spinner1.setAdapter(adapter);


        categories.add("Select Year/Semester");
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {

                // your code here
                item2 = parentView.getItemAtPosition(position).toString();
                //Toast.makeText(parentView.getContext(), "Selected: " + item2, Toast.LENGTH_LONG).show();
                if (item2.matches("First Semester"))
                {
                    branchlist.clear();
                    branchlist.add("First Semester");
                    item3 = "First Semester";
                    sublist.clear();
                    sublist.add("Select Subject");
                    spinner4.setEnabled(false);
                    forthAdapter.notifyDataSetChanged();
                    spinner3.setEnabled(false);
                    spinner4.setEnabled(true);
                    spinner5.setEnabled(false);
                    thirdAdapter.notifyDataSetChanged();
                    forthAdapter.notifyDataSetChanged();
                    fifthAdapter.notifyDataSetChanged();
                    sublist.clear();
                    sublist.add("Select Subject");
                    sublist.add("1001 Mathematics-I");
                    sublist.add("1002 Applied Physics-I");
                    sublist.add("1003 Applied Chemistry");
                    sublist.add("1004 Communication Skills in English");
                }
                else if (item2.matches("Second Semester"))
                {
                    branchlist.clear();
                    branchlist.add("Second Semester");
                    sublist.clear();
                    sublist.add("Select Subject");
                    spinner4.setEnabled(false);
                    forthAdapter.notifyDataSetChanged();
                    item3 = "Second Semester";
                    spinner3.setEnabled(false);
                    spinner4.setEnabled(true);
                    spinner5.setEnabled(false);
                    thirdAdapter.notifyDataSetChanged();
                    forthAdapter.notifyDataSetChanged();
                    fifthAdapter.notifyDataSetChanged();
                    sublist.clear();
                    sublist.add("Select Subject");
                    sublist.add("2001 Mathematics-II");
                    sublist.add("2002 Applied Physics");
                    sublist.add("2003 Introduction to IT Systems");
                    sublist.add("2004 Fundamentals of Electrical & Electronics Engineering");
                    sublist.add("2005 Engineering Mechanics");
                }
                else if (item2.matches("Second Year"))
                {
                    spinner3.setEnabled(true);
                    branchlist.clear();
                    branchlist.add("Select Branch");
                    sublist.clear();
                    sublist.add("Select Subject");
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    spinner4.setEnabled(false);
                    spinner5.setEnabled(false);

                    thirdAdapter.notifyDataSetChanged();
                    branchlist.add("ELECTRONICS ENGINEERING");
                    branchlist.add("ELECTRICAL ENGINEERING");
                    branchlist.add("CIVIL ENGINEERING");
                    branchlist.add("MECHANICAL ENGINEERING");
                    branchlist.add("COMPUTER SCIENCE ENGINEERING");
                }
                else if (item2.matches("Third Year"))
                {
                    spinner3.setEnabled(true);
                    branchlist.clear();
                    branchlist.add("Select Branch");
                    sublist.clear();
                    sublist.add("Select Subject");
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    spinner4.setEnabled(false);
                    spinner5.setEnabled(false);
                    thirdAdapter.notifyDataSetChanged();
                    branchlist.add("ELECTRONICS ENGINEERING");
                    branchlist.add("ELECTRICAL ENGINEERING");
                    branchlist.add("CIVIL ENGINEERING");
                    branchlist.add("MECHANICAL ENGINEERING");
                    branchlist.add("COMPUTER SCIENCE ENGINEERING");
                }
                else
                {
                    spinner3.setEnabled(false);
                    spinner3.setPrompt("Select Branch");
                    spinner4.setEnabled(false);
                    spinner4.setPrompt("Select Subject");
                    spinner5.setEnabled(false);
                    spinner5.setPrompt("Select Unit");
                    branchlist.clear();
                    branchlist.add("Select Branch");

                    sublist.clear();
                    sublist.add("Select Subject");

                    unitlist.clear();
                    unitlist.add("Select Unit");
                    thirdAdapter.notifyDataSetChanged();
                    forthAdapter.notifyDataSetChanged();
                    fifthAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });
        secondAdapter.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
        spinner2.setAdapter(secondAdapter);


        branchlist.add("Select Branch");
        // Drop down layout style - list view with radio button
       thirdAdapter.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
       // attaching data adapter to spinner
        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent3, View view, int position, long id) {
                item3 = parent3.getItemAtPosition(position).toString();
                if ((item3.matches("ELECTRONICS ENGINEERING")) && (item2.matches("Second Year")))
                {
                    spinner4.setEnabled(true);
                    //branchlist.clear();
                    sublist.clear();
                    sublist.add("Select Subject");
                    spinner5.setEnabled(false);
                    forthAdapter.notifyDataSetChanged();
                    sublist.add("EL 201 ELECTRONIC COMPONENTS AND SHOP PRACTICE");
                    sublist.add("EL 202 CIRCUIT ANALYSIS");
                    sublist.add("EL 203 ELECTRONIC MEASUREMENT AND INSTRUMENTATION");
                    sublist.add("EL 204 ELECTONIC DEVICES AND CIRCUITS");
                    sublist.add("EL 205 DIGITAL ELECTRONICS");
                    sublist.add("EL 206 WAVE PROPAGATION AND COMMUNICATION ENGINEERING");
                    sublist.add("EL 207 MICROPROCESSOR");
                    sublist.add("EL 208 AUDIO AND VIDEO SYSTEM");
                    sublist.add("EL 209 ELECTRONIC INSTRUMENT");
                    sublist.add("EL 210 C PROGRAMMING");

                }
                else if ((item3.matches("ELECTRONICS ENGINEERING")) && (item2.matches("Third Year")))
                {
                    spinner4.setEnabled(true);
                    //branchlist.clear();
                    sublist.clear();
                    sublist.add("Select Subject");
                    spinner5.setEnabled(false);
                    forthAdapter.notifyDataSetChanged();
                    sublist.add("EL 301 ELECTRONIC CIRCUITS");
                    sublist.add("EL 302 ADVANCE MICROPROCESSOR AND MICROCONTROLLER");
                    sublist.add("EL 303 ADVANCE COMMUNICATION SYSTEM");
                    sublist.add("EL 304 MICROWAVE AND OPTICAL FBER ENGINEERING");
                    sublist.add("EL 305 POWER AND INDUSTRIAL ELECTRONICS");
                    sublist.add("EL 306 BIO-MEDICAL INSTRUMENTATION");
                    sublist.add("EL 307 LINEAR INTEGRATED CIRCUITS AND DESIGN");
                    sublist.add("EL 308 TELECOMMUNICATION AND SWITCHING NETWORKS");
                    sublist.add("EL 309 COMPUTER COMMUNICATION");
                    sublist.add("EL 310 MANAGEMENT AND ENTERPRENEURSHIP");

                }
                else if ((item3.matches("CIVIL ENGINEERING")) && (item2.matches("Second Year")))
                {
                    spinner4.setEnabled(true);
                    //branchlist.clear();
                    sublist.clear();
                    sublist.add("Select Subject");
                    spinner5.setEnabled(false);
                    forthAdapter.notifyDataSetChanged();
                    sublist.add("CE 201 STRENGTH OF MATERIALS");
                    sublist.add("CE 202 FLUID MECHANICS");
                    sublist.add("CE 203 BUILDING TECHNOLOGY");
                    sublist.add("CE 204 SURVEYING I");
                    sublist.add("CE 205 TRANSPORTATION ENGINEERING");
                    sublist.add("CE 206 SOIL AND FOUNDATION ENGINEERING");
                    sublist.add("CE 207 CONCRETE TECHNOLOGY");
                    sublist.add("CE 208 BUILDING DRAWING");
                    sublist.add("CE 209 CONSTRUCTION MATERIALS AND EQUIPMENTS");
                    sublist.add("CE 210 COMPUTER AIDED DRAWING");

                }
                else if ((item3.matches("CIVIL ENGINEERING")) && (item2.matches("Third Year")))
                {
                    spinner4.setEnabled(true);
                    //branchlist.clear();
                    sublist.clear();
                    sublist.add("Select Subject");
                    spinner5.setEnabled(false);
                    forthAdapter.notifyDataSetChanged();
                    sublist.add("CE 301 THEORY OF STRUCTURE");
                    sublist.add("CE 302 DESIGN OF STEEL STRUCTURE");
                    sublist.add("CE 303 DESIGN OF R.C.C. STRUCTURE");
                    sublist.add("CE 304 SURVEYING II");
                    sublist.add("CE 305 WATER SUPPLY AND SANITARY ENGINEERING");
                    sublist.add("CE 306 IRRIGATION ENGINEERING");
                    sublist.add("CE 307 CIVIL ENGINEERING ESTIMATING AND COSTING");
                    sublist.add("CE 308 ENVIRONMENTALENGINEERING");
                    sublist.add("CE 309 CONSTRUCTION MANAGEMENT AND ACCOUNTS");
                    sublist.add("CE 310 EARTHQUAKE RESISTANT STRUCTURE");
                }
                else if ((item3.matches("ELECTRICAL ENGINEERING")) && (item2.matches("Second Year")))
                {
                    spinner4.setEnabled(true);
                    //branchlist.clear();
                    sublist.clear();
                    sublist.add("Select Subject");
                    spinner5.setEnabled(false);
                    forthAdapter.notifyDataSetChanged();
                    sublist.add("EE 201 BASIC ELECTRONICS");
                    sublist.add("EE 202 Basic Mechanical Engineering");
                    sublist.add("EE 203 Basic Electrical Engineering");
                    sublist.add("EE 204 Electrical Measurement & Instrumentation");
                    sublist.add("EE 205 Electrical Circuit Theory");
                    sublist.add("EE 206 Electrical Machines – I");
                    sublist.add("EE 207 Power System – I");
                    sublist.add("EE 208 Microprocessor & C-Programming");
                    sublist.add("EE 209 Electrical Workshop");
                    sublist.add("EE 210 Management");
                }
                else if ((item3.matches("ELECTRICAL ENGINEERING")) && (item2.matches("Third Year")))
                {
                    spinner4.setEnabled(true);
                    //branchlist.clear();
                    sublist.clear();
                    sublist.add("Select Subject");
                    spinner5.setEnabled(false);
                    forthAdapter.notifyDataSetChanged();
                    sublist.add("EE 301 Power Electronics & Drives");
                    sublist.add("EE 302 Utilization of Electrical Power & Traction");
                    sublist.add("EE 303 Estimating, Costing & Design of Electrical Installations");
                    sublist.add("EE 304 Electrical Design & Drawing");
                    sublist.add("EE 305 Fundamentals of Control System");
                    sublist.add("EE 306 Electrical Machines – II");
                    sublist.add("EE 307 Power System – II");
                    sublist.add("EE 308 Power System – III");
                    sublist.add("EE 309 Switchgear & Protection");
                    sublist.add("EE 310 Energy Management");
                }
                else if ((item3.matches("COMPUTER SCIENCE ENGINEERING")) && (item2.matches("Second Year")))
                {
                    spinner4.setEnabled(true);
                    //branchlist.clear();
                    sublist.clear();
                    sublist.add("Select Subject");
                    spinner5.setEnabled(false);
                    forthAdapter.notifyDataSetChanged();
                    sublist.add("CS 201 PROGRAMMING AND PROBLEM SOLVING THROUGH 'C'");
                    sublist.add("CS 202 COMPUTER SYSTEM ARCHITECTURE");
                    sublist.add("CS 203 OPERATING SYSTEM PRINCIPLE");
                    sublist.add("CS 204 BASICS OF ELECTRONIC DEVICES AND CIRCUITS");
                    sublist.add("CS 205 Basics of Digital Electronics");
                    sublist.add("CS 206 Data Communication");
                    sublist.add("CS 207 Data Base Management System");
                    sublist.add("CS 208 Microprocessor and Interfacing");
                    sublist.add("CS 209 Internet and Web Technologies");
                    sublist.add("CS 210 PC Maintenance and Trouble Shooting");
                }
                else if ((item3.matches("COMPUTER SCIENCE ENGINEERING")) && (item2.matches("Third Year")))
                {
                    spinner4.setEnabled(true);
                    //branchlist.clear();
                    sublist.clear();
                    sublist.add("Select Subject");
                    spinner5.setEnabled(false);
                    forthAdapter.notifyDataSetChanged();
                    sublist.add("CS 301 Data Structure & Algorithm");
                    sublist.add("CS 302 Object Oriented Programming Through C++");
                    sublist.add("CS 303 Unix, Shell Programming and Administration");
                    sublist.add("CS 304 Software Engineering");
                    sublist.add("CS 305 Dot Net Technology");
                    sublist.add("CS 306 Computer Network");
                    sublist.add("CS 307 Data warehouse and mining");
                    sublist.add("CS 308 Introduction to Network Security and Cryptography");
                    sublist.add("CS 309 Java Tools");
                    sublist.add("CS 310 PHP & MySql");
                }
                else if ((item3.matches("MECHANICAL ENGINEERING")) && (item2.matches("Second Year")))
                {
                    spinner4.setEnabled(true);
                    //branchlist.clear();
                    sublist.clear();
                    sublist.add("Select Subject");
                    spinner5.setEnabled(false);
                    forthAdapter.notifyDataSetChanged();
                    sublist.add("ME 201 Strength of Materials");
                    sublist.add("ME 202 Fluid Mechanics & Machines");
                    sublist.add("ME 203 Engg. Materials and Processes");
                    sublist.add("ME 204 Theory Of Machines");
                    sublist.add("ME 205 Machine Drawing and Computer Aided Drafting");
                    sublist.add("ME 206 Basic Automobile Engg.");
                    sublist.add("ME 207 Electrical & Electronics Engg.");
                    sublist.add("ME 208 Thermodynamics & I.C. Engines");
                    sublist.add("ME 209 Workshop Technology & Metrology");
                    sublist.add("ME 210 C Programming");
                }
                else if ((item3.matches("MECHANICAL ENGINEERING")) && (item2.matches("Third Year")))
                {
                    spinner4.setEnabled(true);
                    //branchlist.clear();
                    sublist.clear();
                    sublist.add("Select Subject");
                    spinner5.setEnabled(false);
                    forthAdapter.notifyDataSetChanged();
                    sublist.add("ME 301 Refrigeration and Air Conditioning");
                    sublist.add("ME 302 Processes In Manufacturing");
                    sublist.add("ME 303 Thermal Engineering & Heat Transfer");
                    sublist.add("ME 304 CNC Machines & Automation");
                    sublist.add("ME 305 Power Generation");
                    sublist.add("ME 306 Advance Workshop Techniques");
                    sublist.add("ME 307 Industrial Engineering");
                    sublist.add("ME 308 Machine Design");
                    sublist.add("ME 309 Mechanical Estimating & Costing");
                    sublist.add("ME 310 Management &Entrepreneurship");
                }
                else
                {
                    spinner4.setEnabled(false);
                    //spinner4.setPrompt("Select Subject");
                    spinner5.setEnabled(false);
                    //spinner5.setPrompt("Select Unit");
                    sublist.clear();
                    sublist.add("Select Subject");
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    thirdAdapter.notifyDataSetChanged();
                    forthAdapter.notifyDataSetChanged();
                    fifthAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinner3.setAdapter(thirdAdapter);


        sublist.add("Select Subject");
        forthAdapter.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
        spinner4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent4, View view, int position, long id) {
                item4 = parent4.getItemAtPosition(position).toString();

                if (item4.matches("EL 201 ELECTRONIC COMPONENTS AND SHOP PRACTICE"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: Resistor");
                    unitlist.add("Unit 2: Capacitor");
                    unitlist.add("Unit 3: Inductors and Coil");
                    unitlist.add("Unit 4: Soldering and De-Soldering Techniques");
                    unitlist.add("Unit 5: Printed Circuit Board Fabrication");
                    unitlist.add("Unit 6: Transformer");
                    unitlist.add("Unit 7: Brief idea of surface mounted devices(SMD)");
                }
                else if (item4.matches("EL 202 CIRCUIT ANALYSIS"))
                {
                    spinner5.setEnabled(true);
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: General Network Concept");
                    unitlist.add("Unit 2: Mesh and Nodal Analysis");
                    unitlist.add("Unit 3: Network Theorems");
                    unitlist.add("Unit 4: Laplace Transformation");
                    unitlist.add("Unit 5: Two Port Networks");
                    unitlist.add("Unit 6: Resonance");
                    unitlist.add("Unit 7: Line Filters");
                }
                else if (item4.matches("EL 203 ELECTRONIC MEASUREMENT AND INSTRUMENTATION"))
                {
                    spinner5.setEnabled(true);
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: Basic Concept of Measurement");
                    unitlist.add("Unit 2: Transducers");
                    unitlist.add("Unit 3: Measuring Instruments");
                    unitlist.add("Unit 4: Range Extension and Calibration");
                    unitlist.add("Unit 5: Signal Conditioning");
                    unitlist.add("Unit 6: Control System");
                    unitlist.add("Unit 7: Control System Components");
                }
                else if (item4.matches("EL 204 ELECTONIC DEVICES AND CIRCUITS"))
                {
                    spinner5.setEnabled(true);
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: Semiconductor and PN Junction");
                    unitlist.add("Unit 2: Bipolar Junction Transistor (BJT)");
                    unitlist.add("Unit 3: Transistor Biasing and Bias Stability");
                    unitlist.add("Unit 4: Field Effect Transistor");
                    unitlist.add("Unit 5: Rectifiers and Power Supplies");
                    unitlist.add("Unit 6: Filter Circuits");
                    unitlist.add("Unit 7: Clipper and Clamping Circuit");
                }
                else if (item4.matches("EL 205 DIGITAL ELECTRONICS"))
                {
                    spinner5.setEnabled(true);
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: Introduction");
                    unitlist.add("Unit 2: Boolean Algebra");
                    unitlist.add("Unit 3: Logic Gates");
                    unitlist.add("Unit 4: Minimization Techniques ( K-Mapping)");
                    unitlist.add("Unit 5: Combinational Logic Design");
                    unitlist.add("Unit 6: Sequential Systems");
                }
                else if (item4.matches("EL 206 WAVE PROPAGATION AND COMMUNICATION ENGINEERING"))
                {
                    spinner5.setEnabled(true);
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: Introduction");
                    unitlist.add("Unit 2: EM Wave Propagation");
                    unitlist.add("Unit 3: Antennas");
                    unitlist.add("Unit 4: Noise and Cross Talk");
                    unitlist.add("Unit 5: Amplitude Modulation");
                    unitlist.add("Unit 6: Frequency Modulation");
                    unitlist.add("Unit 7: Radio Receivers");
                }
                else if (item4.matches("EL 207 MICROPROCESSOR"))
                {
                    spinner5.setEnabled(true);
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: Number System");
                    unitlist.add("Unit 2: Introduction of Microprocessor");
                    unitlist.add("Unit 3: The 8085 Architecture");
                    unitlist.add("Unit 4: 8085 Instructions and Programming");
                    unitlist.add("Unit 5: Memory and I/O System");
                    unitlist.add("Unit 6: Instruction Execution and Timings");
                    unitlist.add("Unit 7: Limitation of 8 bit Microprocessor");
                }
                else if (item4.matches("EL 208 AUDIO AND VIDEO SYSTEM"))
                {
                    spinner5.setEnabled(true);
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: Basic Components of Audio and Video");
                    unitlist.add("Unit 2: HI-FI and Stereophony");
                    unitlist.add("Unit 3: Scanning and Composite Video Signal");
                    unitlist.add("Unit 4: T.V. Signal Transmission");
                    unitlist.add("Unit 5: T.V. Receiver");
                    unitlist.add("Unit 6: Colour T.V.");
                    unitlist.add("Unit 7: Basic Concept of New Trends");
                }
                else if (item4.matches("EL 209 ELECTRONIC INSTRUMENT"))
                {
                    spinner5.setEnabled(true);
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: Multimeter");
                    unitlist.add("Unit 2: Electronic Voltmeter");
                    unitlist.add("Unit 3: Cathode Ray Oscilloscope (C.R.O)");
                    unitlist.add("Unit 4: Working Principle and Application of");
                    unitlist.add("Unit 5: Digital Displays");
                    unitlist.add("Unit 6: Guarding Technique");
                }
                else if (item4.matches("EL 210 C PROGRAMMING"))
                {
                    spinner5.setEnabled(true);
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: Introduction");
                    unitlist.add("Unit 2: Elements of â€˜Câ€™");
                    unitlist.add("Unit 3: Console Input-Output");
                    unitlist.add("Unit 4: Control Flow");
                    unitlist.add("Unit 5: Arrays");
                    unitlist.add("Unit 6: Functions");
                    unitlist.add("Unit 7: Pointers");
                    unitlist.add("Unit 8: Structure and Enumerated Data Types");
                }
                else if (item4.matches("EL 301 ELECTRONIC CIRCUITS"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: JFET  and  MOSFET Amplifiers");
                    unitlist.add("Unit 2: Multistage Amplifier");
                    unitlist.add("Unit 3: Power Amplifier");
                    unitlist.add("Unit 4: Feedback Amplifier");
                    unitlist.add("Unit 5: Oscillators");
                    unitlist.add("Unit 6: Transistor at High Frequency and Special Circuit");
                    unitlist.add("Unit 7: Multivibrator");
                    unitlist.add("Unit 8: Blocking Oscillator and Time Base Generators");
                }
                else if (item4.matches("EL 302 ADVANCE MICROPROCESSOR AND MICROCONTROLLER"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: 8086 Microprocessor");
                    unitlist.add("Unit 2: 8086 Instructions and Programming");
                    unitlist.add("Unit 3: I/O Data Transfer Schemes");
                    unitlist.add("Unit 4: Peripheral Devices and their Interfacing with 8085");
                    unitlist.add("Unit 5: Bus Standards");
                    unitlist.add("Unit 6: Introduction to 8051 Microcontroller");
                }
                else if (item4.matches("EL 303 ADVANCE COMMUNICATION SYSTEM"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: Pulse Modulation");
                    unitlist.add("Unit 2: Digital Communication");
                    unitlist.add("Unit 3: Information Theory");
                    unitlist.add("Unit 4: Facsimile System");
                    unitlist.add("Unit 5: Satellite Communication");
                    unitlist.add("Unit 6: Mobile Communication");
                }
                else if (item4.matches("EL 304 MICROWAVE AND OPTICAL FBER ENGINEERING"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: Microwave");
                    unitlist.add("Unit 2: Microwave Vacuum Tube Devices");
                    unitlist.add("Unit 3: Microwave Solid State Devices");
                    unitlist.add("Unit 4: Microwave Components");
                    unitlist.add("Unit 5: Microwave Measurement");
                    unitlist.add("Unit 6: Optical Fibre Communication");
                }
                else if (item4.matches("EL 305 POWER AND INDUSTRIAL ELECTRONICS"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: Introduction");
                    unitlist.add("Unit 2: Power Control and Rectifiers");
                    unitlist.add("Unit 3: Inverters, Choppers and Cyclo-converters");
                    unitlist.add("Unit 4: AC Stabilizer and Power Supply");
                    unitlist.add("Unit 6: Heating, Welding and their Application");
                }
                else if (item4.matches("EL 306 BIO-MEDICAL INSTRUMENTATION"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: Introduction to Physiology");
                    unitlist.add("Unit 2: Medical Electrodes");
                    unitlist.add("Unit 3: Bio Medical Recording System");
                    unitlist.add("Unit 4: Electro Cardiograph (E.C.G.)");
                    unitlist.add("Unit 5: Pace Makers");
                    unitlist.add("Unit 6: Blood Pressure Monitoring");
                    unitlist.add("Unit 7: Defibrillator");
                    unitlist.add("Unit 8: Biomedical Instruments");
                    unitlist.add("Unit 9: Bed Patient Monitoring System");
                    unitlist.add("Unit 10: Introduction to Bioinformatics");
                    unitlist.add("Unit 11: Use of Nanotechnology in biomedical (Brief idea)");
                }
                else if (item4.matches("EL 307 LINEAR INTEGRATED CIRCUITS AND DESIGN"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: IC Fabrication");
                    unitlist.add("Unit 2: Operational Amplifier");
                    unitlist.add("Unit 3: Timer Chip 555");
                    unitlist.add("Unit 4: Voltage Regulation");
                    unitlist.add("Unit 5: Phase Locked Loop");
                    unitlist.add("Unit 6: Design of Digital Circuits");
                }
                else if (item4.matches("EL 308 TELECOMMUNICATION AND SWITCHING NETWORKS"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: Introduction");
                    unitlist.add("Unit 2: Electronic Space Switching");
                    unitlist.add("Unit 3: Time Division Switching");
                    unitlist.add("Unit 4: Traffic Analysis");
                    unitlist.add("Unit 5: Brief Idea of");
                }
                else if (item4.matches("EL 309 COMPUTER COMMUNICATION"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: Introduction");
                    unitlist.add("Unit 2: Network Fundamental");
                    unitlist.add("Unit 3: Data Link and Medium Access");
                    unitlist.add("Unit 4: Backbone Networks");
                    unitlist.add("Unit 5: Network Protocols");
                }
                else if (item4.matches("EL 310 MANAGEMENT AND ENTERPRENEURSHIP"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: Principles of Management");
                    unitlist.add("Unit 2: Human Resources Development");
                    unitlist.add("Unit 3: Wages and Incentives");
                    unitlist.add("Unit 4: Material Management");
                    unitlist.add("Unit 5: Financial Management");
                    unitlist.add("Unit 6: Marketing Management");
                    unitlist.add("Unit 7: Entrepreneurship");
                    unitlist.add("Unit 8: Entrepreneurial Development");
                    unitlist.add("Unit 9: Entrepreneurship Support System");
                    unitlist.add("Unit 10: Setting up SSI");
                    unitlist.add("Unit 11: Tax System and Insurance");
                    unitlist.add("Unit 12: Financial Sources for SSI");
                    unitlist.add("Unit 13: Labour Legislation and Pollution Control Acts");
                    unitlist.add("Unit 14: Project Report");
                    unitlist.add("Unit 15: ISO  9000 Series of Quality System");
                }
                else if (item4.matches("1001 Mathematics-I"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. TRIGONOMETRY");
                    unitlist.add("Unit 2. DIFFERENTIAL CALCULUS");
                    unitlist.add("Unit 3. COMPLEX NUMBERS");
                    unitlist.add("Unit 4. PARTIAL FRACTIONS");
                    unitlist.add("Unit 5. PERMUTATIONS, COMBINATIONS AND BINOMIAL THEOREM");
                }
                else if (item4.matches("1002 Applied Physics-I"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. PHYSICAL WORLD, UNITS AND MEASUREMENTS");
                    unitlist.add("Unit 2. FORCE WORK AND ENERGY");
                    unitlist.add("Unit 3. ROTATIONAL MOTION");
                    unitlist.add("Unit 4. PROPERTIES OF MATTER");
                    unitlist.add("Unit 5. HEAT AND THERMOMETRY");
                }
                else if (item4.matches("1003 Applied Chemistry"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Atomic Structure, Chemical Bonding and Solutions:");
                    unitlist.add("Unit 2. WATER");
                    unitlist.add("Unit 3. ENGINEERING MATERIALS");
                    unitlist.add("Unit 4. CHEMISTRY OF FUELS AND LUBRICANTS");
                    unitlist.add("Unit 5. ELECTRO CHEMISTRY");
                }
                else if (item4.matches("1004 Communication Skills in English"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. COMMUNICATION THEORY AND PRACTICE");
                    unitlist.add("Unit 2. SOFT SKILLS FOR PROFESSIONAL EXCELLENCE");
                    unitlist.add("Unit 3. READING COMPREHENSION");
                    unitlist.add("Unit 4. PROFESSIONAL WRITING");
                    unitlist.add("Unit 5. VOCABULARY AND GRAMMAR");
                }
                else if (item4.matches("CE 201 STRENGTH OF MATERIALS"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. SIMPLE STRESS & STRAIN");
                    unitlist.add("Unit 2. Compound Stress");
                    unitlist.add("Unit 3. Strain Energy:");
                    unitlist.add("Unit 4. Bending Moments and Shear Force:");
                    unitlist.add("Unit 5. Moment of Inertia:");
                    unitlist.add("Unit 6. Bending Stresses in Beams:");
                    unitlist.add("Unit 7. Shear Stress in Beams:");
                    unitlist.add("Unit 8. Deflection:");
                    unitlist.add("Unit 9. Columns and Struts:");
                    unitlist.add("Unit 10. Torsion of Shaft:");
                    unitlist.add("Unit 11. Springs:");
                    unitlist.add("Unit 12. Thin Cylindrical Shells:");
                    unitlist.add("Unit 13. Combined Direct and Bending Stress:");

                }
                else if (item4.matches("CE 202 FLUID MECHANICS"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction:");
                    unitlist.add("Unit 2. Fluid Pressure and its Measurement:");
                    unitlist.add("Unit 3. Hydrostatics:");
                    unitlist.add("Unit 4. Hydrokinematics :");
                    unitlist.add("Unit 5. Hydrodynamics and Measurement of Flow:");
                    unitlist.add("Unit 6. Orifices and Notches:");
                    unitlist.add("Unit 7. Flow Through Pipes:");
                    unitlist.add("Unit 8. Flow through Channels:");
                    unitlist.add("Unit 9. Turbines :");
                    unitlist.add("Unit 10. Pumps :");

                }
                else if (item4.matches("CE 203 BUILDING TECHNOLOGY"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction :");
                    unitlist.add("Unit 2. Foundation :");
                    unitlist.add("Unit 3. Walls :");
                    unitlist.add("Unit 4. Brick Masonry :");
                    unitlist.add("Unit 5. Stone Masonry :");
                    unitlist.add("Unit 6. Scaffolding, Shoring and Underpinning :");
                    unitlist.add("Unit 7. Dampness and its Prevention:");
                    unitlist.add("Unit 8. Arches and Lintels :");
                    unitlist.add("Unit 9. Doors :");
                    unitlist.add("Unit 10. Windows :");
                    unitlist.add("Unit 11. Stairs and Stair Cases :");
                    unitlist.add("Unit 12. Roofs :");
                    unitlist.add("Unit 13. Floors :");
                    unitlist.add("Unit 14. Finishing of buildings :");
                    unitlist.add("Unit 15. Building Bye Laws :");
                    unitlist.add("Unit 16. Basic Principles of Building Planning:");
                    unitlist.add("Unit 17. Orientation :");
                    unitlist.add("Unit 18. Site Selection :");
                    unitlist.add("Unit 19. Design of Buildings :");

                }
                else if (item4.matches("CE 204 SURVEYING I"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction :");
                    unitlist.add("Unit 2. Chain Surveying :");
                    unitlist.add("Unit 3. Compass Surveying :");
                    unitlist.add("Unit 4. Levelling :");
                    unitlist.add("Unit 5. Contouring :");
                    unitlist.add("Unit 6. Plane Table Surveying :");
                    unitlist.add("Unit 7. Minor Instrument :");
                }
                else if (item4.matches("CE 205 TRANSPORTATION ENGINEERING"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction :");
                    unitlist.add("Unit 2. Highway Development and Planning :");
                    unitlist.add("Unit 3. Highway Geometric Design :");
                    unitlist.add("Unit 4. Traffic Engineering :");
                    unitlist.add("Unit 5. Highway Materials :");
                    unitlist.add("Unit 6. Construction of Roads :");
                    unitlist.add("Unit 7. Highway Maintenance :");
                    unitlist.add("Unit 8. Road Drainage and Road Arboriculture :");
                    unitlist.add("Unit 9. Bridges :");
                    unitlist.add("Unit 10. Railways :");
                    unitlist.add("Unit 11. Rails :");
                    unitlist.add("Unit 12. Sleepers :");
                    unitlist.add("Unit 13. Ballast :");
                    unitlist.add("Unit 14. Fixture and Fastenings :");
                    unitlist.add("Unit 15. Railway Geometries :");
                    unitlist.add("Unit 16. Points and Crossing :");
                    unitlist.add("Unit 17. Tracks Laying :");
                    unitlist.add("Unit 18. Maintenance :");
                    unitlist.add("Unit 19. Stations and Yards :");
                    unitlist.add("Unit 20. Signallings :");
                    unitlist.add("Unit 21. Tunnelling :");

                }
                else if (item4.matches("CE 206 SOIL AND FOUNDATION ENGINEERING"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction :");
                    unitlist.add("Unit 2. Fundamental Definitions and Relationships :");
                    unitlist.add("Unit 3. Classification of Soils :");
                    unitlist.add("Unit 4. Permeability of Soils:");
                    unitlist.add("Unit 5. Compaction :");
                    unitlist.add("Unit 6. Consolidation :");
                    unitlist.add("Unit 7. Shear strength :");
                    unitlist.add("Unit 8. Bearing Capacity :");
                    unitlist.add("Unit 9. Earth Pressures :");
                    unitlist.add("Unit 10. Soil Exploration :");
                    unitlist.add("Unit 11. Foundation :");
                    unitlist.add("Unit 12. Pile Foundation :");
                    unitlist.add("Unit 13. Soil Stablisation :");
                }
                else if (item4.matches("CE 207 CONCRETE TECHNOLOGY"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Cement :");
                    unitlist.add("Unit 2. Aggregates :");
                    unitlist.add("Unit 3. Water :");
                    unitlist.add("Unit 4. Admixtures and Construction Chemical :");
                    unitlist.add("Unit 5. Fresh Concrete :");
                    unitlist.add("Unit 6. Concrete Operation :");
                    unitlist.add("Unit 7. Strength of Concrete :");
                    unitlist.add("Unit 8. Special Concrete :");
                    unitlist.add("Unit 9. Formwork :");
                    unitlist.add("Unit 10. Quality Control at Site :");
                    unitlist.add("Unit 11. Concrete Mix Design :");
                    unitlist.add("Unit 12. Deterioration and Restoration of Concrete :");
                }
                else if (item4.matches("CE 208 BUILDING DRAWING"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Detailed working plan, elevation and section of the following.");
                    unitlist.add("Unit 2. Drawing of a small residential building from measurements");
                    unitlist.add("Unit 3. Detailed working plan, elevation and section through stair-case drawing of a two storied building.");
                }
                else if (item4.matches("CE 209 CONSTRUCTION MATERIALS AND EQUIPMENTS"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Stones :");
                    unitlist.add("Unit 2. Bricks :");
                    unitlist.add("Unit 3. Tiles :");
                    unitlist.add("Unit 4. Lime :");
                    unitlist.add("Unit 5. Lime Mortar :");
                    unitlist.add("Unit 6. Cement and Cement Mortar :");
                    unitlist.add("Unit 7. Timber :");
                    unitlist.add("Unit 8. Ferrous Material :");
                    unitlist.add("Unit 9. Non Ferrous Metals :");
                    unitlist.add("Unit 10. Glass :");
                    unitlist.add("Unit 11. Paints and Varnishes :");
                    unitlist.add("Unit 12. Equipment for Earth Work and Compaction :");
                    unitlist.add("Unit 13. Bitumen or Asphalt Mixing Plant :");
                    unitlist.add("Unit 14. Hauling Equipment");
                    unitlist.add("Unit 15. Equipment for Concreting :");

                }
                else if (item4.matches("CE 210 COMPUTER AIDED DRAWING"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Getting Started – I");
                    unitlist.add("Unit 2. Getting Started – II");
                    unitlist.add("Unit 3. Draw Commands");
                    unitlist.add("Unit 4. Editing Commands");
                    unitlist.add("Unit 5. Drawing Aids");
                    unitlist.add("Unit 6. Creating Text");
                    unitlist.add("Unit 7. Basic Dimensioning");
                    unitlist.add("Unit 8. Inquiry Commands");
                    unitlist.add("Unit 9. Editing Dimensions");
                    unitlist.add("Unit 10. Hatching");
                    unitlist.add("Unit 11. Blocks");
                    unitlist.add("Unit 12. Plotting Drawings in AutoCAD");
                    unitlist.add("Unit 13. Draw working plan, elevation of the following.");
                }
                else if (item4.matches("CE 301 THEORY OF STRUCTURE"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Frames :");
                    unitlist.add("Unit 2. Slope and Deflection :");
                    unitlist.add("Unit 3. Propped Cantilever Beam :");
                    unitlist.add("Unit 4. Fixed Beams :");
                    unitlist.add("Unit 5. Continuous Beams :");
                    unitlist.add("Unit 6. Rolling Loads :");
                    unitlist.add("Unit 7. Influence Line Diagram for the following in Simply Supported Beams :");
                    unitlist.add("Unit 8. Three Hinged Arch :");
                    unitlist.add("Unit 9. Retaining Walls :");
                    unitlist.add("Unit 10. Indeterminate Structures :");

                }
                else if (item4.matches("CE 302 DESIGN OF STEEL STRUCTURE"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction :");
                    unitlist.add("Unit 2. Bolted Connections :");
                    unitlist.add("Unit 3. Welded Connections :");
                    unitlist.add("Unit 4. Design of Tension Members:");
                    unitlist.add("Unit 5. Compression Members:");
                    unitlist.add("Unit 6. Column Bases:");
                    unitlist.add("Unit 7. Design of Beams:");
                    unitlist.add("Unit 8. Roof Trusses:");
                    unitlist.add("Unit 9. Plate Girder:");
                }
                else if (item4.matches("CE 303 DESIGN OF R.C.C. STRUCTURE"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction :");
                    unitlist.add("Unit 2. Flexural Members :");
                    unitlist.add("Unit 3. Analysis and Design of Beams :");
                    unitlist.add("Unit 4. Slabs :");
                    unitlist.add("Unit 5. Compression Members (axially loaded columns) :");
                    unitlist.add("Unit 6. Design of Footing :");
                    unitlist.add("Unit 7. Retaining Wall :");
                    unitlist.add("Unit 8. Prestressed Concrete :");
                }
                else if (item4.matches("CE 304 SURVEYING II"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Theodolite :");
                    unitlist.add("Unit 2. Traverse :");
                    unitlist.add("Unit 3. Tacheometry :");
                    unitlist.add("Unit 4. Trigonometrical Levelling :");
                    unitlist.add("Unit 5. Curves :");
                    unitlist.add("Unit 6. Mine Surveying :");
                    unitlist.add("Unit 7. Modern Instruments - Brief Description :");
                }
                else if (item4.matches("CE 305 WATER SUPPLY AND SANITARY ENGINEERING"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Water Demand and Quantity :");
                    unitlist.add("Unit 2. Quality of Water :");
                    unitlist.add("Unit 3. Treatment of Water :");
                    unitlist.add("Unit 4. Regulatory Valves :");
                    unitlist.add("Unit 5. Distribution of Water :");
                    unitlist.add("Unit 6. Rural Water Supply :");
                    unitlist.add("Unit 7. System of Sanitation :");
                    unitlist.add("Unit 8. Quantity of Sewage :");
                    unitlist.add("Unit 9. Characteristics and Composition of Sewage :");
                    unitlist.add("Unit 10. Building Drainage :");
                    unitlist.add("Unit 11. Sewerage Systems :");
                    unitlist.add("Unit 12. Appurtenances :");
                    unitlist.add("Unit 13. Laying of Sewers :");
                    unitlist.add("Unit 14. Maintenance :");
                    unitlist.add("Unit 15. Sewage Disposal :");
                    unitlist.add("Unit 16. Treatment and Disposal :");
                    unitlist.add("Unit 17. Rural Sanitation :");

                }
                else if (item4.matches("CE 306 IRRIGATION ENGINEERING"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction:");
                    unitlist.add("Unit 2. Water Requirements of Crops :");
                    unitlist.add("Unit 3. Hydrology:");
                    unitlist.add("Unit 4. Dams :");
                    unitlist.add("Unit 5. Earthen and Rock fill Dams :");
                    unitlist.add("Unit 6. Spillways :");
                    unitlist.add("Unit 7. River Training Works :");
                    unitlist.add("Unit 8. Canals :");
                    unitlist.add("Unit 9. Water Logging :");
                    unitlist.add("Unit 10. Diversion Head Works :");
                    unitlist.add("Unit 11. Cross Drainage Works :");
                    unitlist.add("Unit 12. Distributory Works :");
                    unitlist.add("Unit 13. Well Irrigation :");
                }
                else if (item4.matches("CE 307 CIVIL ENGINEERING ESTIMATING AND COSTING"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction :");
                    unitlist.add("Unit 2. Rate-Analysis :");
                    unitlist.add("Unit 3. Specifications :");
                    unitlist.add("Unit 4. Detailed Estimates for Buildings :");
                    unitlist.add("Unit 5. Earth Work Calculations for Road & Rail Formation :");
                    unitlist.add("Unit 6. Preparing Detailed Estimates for the Various Items of Work from the given Drawing for");
                    unitlist.add("Unit 7. Valuation of Property and Rent Fixation :");
                    unitlist.add("Unit 8. Procedure of Works :");
                    unitlist.add("Unit 9. Stores, Tools and Plants :");
                }
                else if (item4.matches("CE 308 ENVIRONMENTALENGINEERING"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Environment and Ecology :");
                    unitlist.add("Unit 2. Factors Affecting Environmental Pollution :");
                    unitlist.add("Unit 3. Water Pollution :");
                    unitlist.add("Unit 4. Air Pollution :");
                    unitlist.add("Unit 5. Noise Pollution :");
                    unitlist.add("Unit 6. Land Pollution :");
                    unitlist.add("Unit 7. Environmental Impact Assessment (EIA) :");
                    unitlist.add("Unit 8. Global Environmental Issues :");
                    unitlist.add("Unit 9. Non Conventional Sources of Energy in Environmental Protection.");
                    unitlist.add("Unit 10. Pollution Control Acts :");
                    unitlist.add("Unit 11. Environment Laws :");

                }
                else if (item4.matches("CE 309 CONSTRUCTION MANAGEMENT AND ACCOUNTS"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction :");
                    unitlist.add("Unit 2. Construction Planning :");
                    unitlist.add("Unit 3. Organisation :");
                    unitlist.add("Unit 4. Construction Contracts :");
                    unitlist.add("Unit 5. Construction Labour :");
                    unitlist.add("Unit 6. Inspection and Quality Control :");
                    unitlist.add("Unit 7. Construction Safety :");
                    unitlist.add("Unit 8. Public Works Accounts :");
                }
                else if (item4.matches("CE 310 EARTHQUAKE RESISTANT STRUCTURE"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Engineering Seismology :");
                    unitlist.add("Unit 2. Structural Dynamics :");
                    unitlist.add("Unit 3. Behaviour of Buildings During Earthquakes :");
                    unitlist.add("Unit 4. Provisions for Seismic Strengthening of Masonry Constructions :");
                    unitlist.add("Unit 5. Seismic Performance of Reinforced Concrete Buildings :");
                    unitlist.add("Unit 6. Ductile Detailing of Reinforced Concrete Buildings :");
                    unitlist.add("Unit 7. Disaster Management :");
                }
                else if (item4.matches("EE 201 BASIC ELECTRONICS"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Semi Conductor Diode");
                    unitlist.add("Unit 2. Bi-Polar Junction Transistor");
                    unitlist.add("Unit 3. R-C Coupled and Power Amplifier");
                    unitlist.add("Unit 4. Special Devices");
                    unitlist.add("Unit 5. Feed Back and Oscillators");
                    unitlist.add("Unit 6. Classification of Electrical Signals");
                    unitlist.add("Unit 7. Logic Gates");
                    unitlist.add("Unit 8. Boolean Algebra");
                    unitlist.add("Unit 9. Combinational Circuits");
                    unitlist.add("Unit 10. Sequential Circuits");

                }
                else if (item4.matches("EE 202 Basic Mechanical Engineering"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Mechanical Properties of Metals");
                    unitlist.add("Unit 2. Basic Concept of Thermal Engineering");
                    unitlist.add("Unit 3. Hydraulics");
                    unitlist.add("Unit 4. Pressure Measuring Devices");
                    unitlist.add("Unit 5. Bernaulli's Theorem");
                    unitlist.add("Unit 6. Pumps");
                    unitlist.add("Unit 7. Turbine");
                    unitlist.add("Unit 8. Properties of Steam");
                    unitlist.add("Unit 9.  Boilers");
                    unitlist.add("Unit 10. Steam Turbines");
                    unitlist.add("Unit 11. I.C. Engines");
                    unitlist.add("Unit 12. Transmission");
                    unitlist.add("Unit 13. Lubrication");

                }
                else if (item4.matches("EE 203 Basic Electrical Engineering"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. D.C. Circuits");
                    unitlist.add("Unit 2. Capacitance");
                    unitlist.add("Unit 3. Magnetic Circuits");
                    unitlist.add("Unit 4. Phasor Algebra");
                    unitlist.add("Unit 5. A.C. Circuits");
                    unitlist.add("Unit 6. Polyphase System");
                    unitlist.add("Unit 7. Battery");
                    unitlist.add("Unit 8. Classification of Electrical Engineering Materials :");
                    unitlist.add("Unit 9. Conducting Materials");
                    unitlist.add("Unit 10. Insulating Materials");
                    unitlist.add("Unit 11. Magnetic Materials");
                    unitlist.add("Unit 12. Special Purpose Materials");

                }
                else if (item4.matches("EE 204 Electrical Measurement & Instrumentation"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction to Measuring Instruments");
                    unitlist.add("Unit 2. Different Measuring Instruments");
                    unitlist.add("Unit 3. Measurement of Resistance");
                    unitlist.add("Unit 4. Potentiometers");
                    unitlist.add("Unit 5. A.C. Bridge");
                    unitlist.add("Unit 6. Brief study of");
                    unitlist.add("Unit 7. Instrumentation System");
                    unitlist.add("Unit 8. Transducers");
                    unitlist.add("Unit 9. Measurement of Following Physical Parameter using Suitable Transducers");
                    unitlist.add("Unit 10. Instrument Transformers");
                }
                else if (item4.matches("EE 205 Electrical Circuit Theory"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Network Parameters");
                    unitlist.add("Unit 2. Network Theorems");
                    unitlist.add("Unit 3. Resonance");
                    unitlist.add("Unit 4. Circuit Transients");
                    unitlist.add("Unit 5. Two Port Network");
                    unitlist.add("Unit 6. Complex Frequency and Pole-Zero Diagram");
                }
                else if (item4.matches("EE 206 Electrical Machines – I"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. D.C. Generator");
                    unitlist.add("Unit 2. D.C. Motor");
                    unitlist.add("Unit 3. Transformer");
                }
                else if (item4.matches("EE 207 Power System – I"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction");
                    unitlist.add("Unit 2. Thermal Power Station");
                    unitlist.add("Unit 3. Hydro Electric Power Plants");
                    unitlist.add("Unit 4. Nuclear Power Station");
                    unitlist.add("Unit 5. Diesel Power Plants");
                    unitlist.add("Unit 6. Solar Energy");
                    unitlist.add("Unit 7. Wind Energy");
                    unitlist.add("Unit 8. Bio-Gas Energy");
                    unitlist.add("Unit 9. Ocean Energy");
                }
                else if (item4.matches("EE 208 Microprocessor & C-Programming"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction");
                    unitlist.add("Unit 2. Microprocessors Architecture (Intel 8085 )");
                    unitlist.add("Unit 3. Programming and Application of Microprocessor");
                    unitlist.add("Unit 4. Introduction of ‘C’ Language");
                    unitlist.add("Unit 5. Elements of ‘C’");
                    unitlist.add("Unit 6. Console Input-Output");
                    unitlist.add("Unit 7. Control Flow");
                    unitlist.add("Unit 8. Arrays");
                    unitlist.add("Unit 9. Functions");
                    unitlist.add("Unit 10. Pointers");
                    unitlist.add("Unit 11. Structure and Enumerated Data Types");
                }
                else if (item4.matches("EE 209 Electrical Workshop"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Wire Joints");
                    unitlist.add("Unit 2. Wiring");
                    unitlist.add("Unit 3. Fault Investigation and Testing");
                    unitlist.add("Unit 4. Automobile Electrical System");
                    unitlist.add("Unit 5. Domestic Appliances");
                    unitlist.add("Unit 6. Introduction of Electrical Maintenance");
                    unitlist.add("Unit 7. Maintenance and Repair of Storage Batteries");
                    unitlist.add("Unit 8. Maintenance and Repair of Transformers");
                    unitlist.add("Unit 9. Maintenance and Repair of D.C. Motors");
                    unitlist.add("Unit 10. Maintenance and Repair of A.C Motors");
                    unitlist.add("Unit 11. Maintenance and Repairs of Circuit Breakers");
                    unitlist.add("Unit 12. Safety Measures");

                }
                else if (item4.matches("EE 210 Management"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Entrepreneurship");
                    unitlist.add("Unit 2. Entrepreneurship Support System");
                    unitlist.add("Unit 3. Setting up SSI");
                    unitlist.add("Unit 4. Raw Material Management");
                    unitlist.add("Unit 5. Marketing Facilities");
                    unitlist.add("Unit 6. Financial Sources for SSI");
                    unitlist.add("Unit 7. Contracts and Tenders");
                    unitlist.add("Unit 8. Project Report");
                    unitlist.add("Unit 9. ISO  9000 Series of Quality System");
                    unitlist.add("Unit 10. Principles of Management");
                    unitlist.add("Unit 11. Human Resources Development");
                    unitlist.add("Unit 12. Wages and Incentives");
                    unitlist.add("Unit 13. Marketing Management");
                    unitlist.add("Unit 14. Tax System and Insurance");
                    unitlist.add("Unit 15. Labour Legislation and Pollution Control Acts");

                }
                else if (item4.matches("EE 301 Power Electronics & Drives"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction");
                    unitlist.add("Unit 2. Power Control Rectification");
                    unitlist.add("Unit 3. Inverter");
                    unitlist.add("Unit 4. Chopper");
                    unitlist.add("Unit 5. Cycloconvertor");
                    unitlist.add("Unit 6. SMPS");
                    unitlist.add("Unit 7. AC Stabilizer");
                    unitlist.add("Unit 8. Speed Control of Motors");
                    unitlist.add("Unit 9. Time");
                }
                else if (item4.matches("EE 302 Utilization of Electrical Power & Traction"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Industrial Utilization");
                    unitlist.add("Unit 2. Electric Heating");
                    unitlist.add("Unit 3. Electric Welding");
                    unitlist.add("Unit 4. Illumination");
                    unitlist.add("Unit 5 Traction Systems");
                    unitlist.add("Unit 6 Train Movement and Energy Consumption");
                    unitlist.add("Unit 7. Electric Traction Motors");
                    unitlist.add("Unit 8 Power Supply");
                }
                else if (item4.matches("EE 303 Estimating, Costing & Design of Electrical Installations"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Wiring Materials and Accessories");
                    unitlist.add("Unit 2. General Principle of Estimating and Costing");
                    unitlist.add("Unit 3. Earthing");
                    unitlist.add("Unit 4. Service Connection");
                    unitlist.add("Unit 5. Plan Estimation of 1-?and 3-? Electrical load");
                    unitlist.add("Unit 6. Design of Distribution Lines");
                    unitlist.add("Unit 7. Sub Station");
                    unitlist.add("Unit 8 Description and Layout of Grid Substation 33/11 and 220/132 KV");
                    unitlist.add("Unit 9. Design of a Distribution Scheme for a Small Colony");
                }
                else if (item4.matches("EE 304 Electrical Design & Drawing"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Transformer Design");
                    unitlist.add("Unit 2. Design of Winding");
                    unitlist.add("Unit 3. D.C. Machine Design");
                    unitlist.add("Unit 4. 3-Phase Induction Motor Design");
                    unitlist.add("Unit 5. Simple Alarm and Signal Circuits");
                    unitlist.add("Unit 6. Contactor Control Circuits");
                    unitlist.add("Unit 7. Panel Wiring Diagram   Panel wiring   diagram   for  the  following with usual protective devices and showing the various equipment with suitable ranges");
                }
                else if (item4.matches("EE 305 Fundamentals of Control System"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Control System");
                    unitlist.add("Unit 2. Control System Components");
                    unitlist.add("Unit 3. Time Domain Analysis");
                    unitlist.add("Unit 4. Frequency Response");
                    unitlist.add("Unit 5. Root Locus");
                }
                else if (item4.matches("EE 306 Electrical Machines – II"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Induction Motor");
                    unitlist.add("Unit 2. Single Phase Induction Motor");
                    unitlist.add("Unit 3. Alternators");
                    unitlist.add("Unit 4. Synchronous Motors");
                    unitlist.add("Unit 5. Stability Analysis of Synchronous Machines");
                    unitlist.add("Unit 6. Special Machines");
                }
                else if (item4.matches("EE 307 Power System – II"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Transmission and Distribution");
                    unitlist.add("Unit 2. Materials used in Overhead Lines");
                    unitlist.add("Unit 3. Mechanical Design");
                    unitlist.add("Unit 4. Electrical Design");
                    unitlist.add("Unit 5. D.C. Distribution Systems");
                    unitlist.add("Unit 6. A. C. Distribution Systems");
                    unitlist.add("Unit 7. Construction of Underground Distribution Lines");
                    unitlist.add("Unit 8. Construction of Overhead Distribution Lines");
                }
                else if (item4.matches("EE 308 Power System – III"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Load and Load Curves");
                    unitlist.add("Unit 2. Economic Aspects of Generation");
                    unitlist.add("Unit 3. Tariffs");
                    unitlist.add("Unit 4. Power Factor Improvement");
                    unitlist.add("Unit 5. Combined Operation of Power Stations");
                    unitlist.add("Unit 6. Control of Voltage and Reactive Power");
                    unitlist.add("Unit 7. Extra High Voltages Transmission");
                    unitlist.add("Unit 8. HVDC Transmission");
                    unitlist.add("Unit 9. Corona");
                }
                else if (item4.matches("EE 309 Switchgear & Protection"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Faults in Power System");
                    unitlist.add("Unit 2. Symmetrical Components");
                    unitlist.add("Unit 3. Fuses");
                    unitlist.add("Unit 4. Circuit Breakers");
                    unitlist.add("Unit 5. Protection");
                    unitlist.add("Unit 6. Protection of Alternator");
                    unitlist.add("Unit 7. Transformer Protection");
                    unitlist.add("Unit 8. Line Protection");
                    unitlist.add("Unit 9. Over Voltage Protection");
                }
                else if (item4.matches("EE 310 Energy Management"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Energy Management and Energy Planning");
                    unitlist.add("Unit 2. Energy and Power Management");
                    unitlist.add("Unit 3. Energy Audit");
                    unitlist.add("Unit 4. Energy Conversation");
                    unitlist.add("Unit 5. Environmental Aspects of Energy and Pollution Control");
                    unitlist.add("Unit 6. Energy and Sustainable Development");
                }
                else if (item4.matches("2001 Mathematics-II"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: DETERMINANTS AND MATRICES");
                    unitlist.add("Unit 2: INTEGRAL CALCULUS AND DIFFERENTIAL EQUATIONS");
                    unitlist.add("Unit 3: TWO-DIMENSIONALCO-ORDINATE GEOMETRY");
                    unitlist.add("Unit 4: CIRCLE AND CONICS");
                    unitlist.add("Unit 5: VECTOR ALGEBRA");
                }
                else if (item4.matches("2002 Applied Physics"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: WAVE MOTION AND ITS APPLICATIONS");
                    unitlist.add("Unit 2: OPTICS");
                    unitlist.add("Unit 3: ELECTROSTATICS AND CURRENT ELECTRICITY");
                    unitlist.add("Unit 4: ELECTROMAGNETISM");
                    unitlist.add("Unit 5: SEMICONDUCTOR AND MODERN PHYSICS");
                }
                else if (item4.matches("2003 Introduction to IT Systems"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: BASIC COMPUTER & INTERNET SKILLS");
                    unitlist.add("Unit 2: OPERATING SYSTEMS");
                    unitlist.add("Unit 3: BASICS OF WEB DEVELOPMENT");
                    unitlist.add("Unit 4: OFFICE TOOLS");
                    unitlist.add("Unit 5: INFORMATION SECURITY BEST PRACTICES");
                }
                else if (item4.matches("2004 Fundamentals of Electrical & Electronics Engineering"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: OVERVIEW OF ELECTRONIC COMPONENTS & SIGNALS");
                    unitlist.add("Unit 2: OVERVIEW OF BASIC (ANALOG) & DIGITAL ELECTRONICS");
                    unitlist.add("Unit 3: ELECTRIC AND MAGNETIC CIRCUITS");
                    unitlist.add("Unit 4: A.C. CIRCUITS");
                    unitlist.add("Unit 5: TRANSFORMERS");
                }
                else if (item4.matches("2005 Engineering Mechanics"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1: BASICS OF MECHANICS AND FORCE SYSTEM");
                    unitlist.add("Unit 2: EQUILIBRIUM");
                    unitlist.add("Unit 3: FRICTION");
                    unitlist.add("Unit 4: CENTROID AND CENTRE OF GRAVITY");
                    unitlist.add("Unit 5: SIMPLE LIFTING MACHINE");
                }
                else if (item4.matches("ME 201 Strength of Materials"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. SIMPLE STRESS & STRAIN");
                    unitlist.add("Unit 2. Compound Stress");
                    unitlist.add("Unit 3. Strain Energy:");
                    unitlist.add("Unit 4. Bending Moments and Shear Force:");
                    unitlist.add("Unit 5. Moment of Inertia:");
                    unitlist.add("Unit 6. Bending Stresses in Beams:");
                    unitlist.add("Unit 7. Shear Stress in Beams:");
                    unitlist.add("Unit 8. Deflection:");
                    unitlist.add("Unit 9. Columns and Struts:");
                    unitlist.add("Unit 10. Torsion of Shaft:");
                    unitlist.add("Unit 11. Springs:");
                    unitlist.add("Unit 12. Thin Cylindrical Shells:");
                    unitlist.add("Unit 13. Combined Direct and Bending Stress:");
                }
                else if (item4.matches("ME 202 Fluid Mechanics & Machines"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 11. Reciprocating Pump :");
                }
                else if (item4.matches("ME 203 Engg. Materials and Processes"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Classification and Properties of Materials :");
                    unitlist.add("Unit 2. Structure of Metals and Their Deformation :");
                    unitlist.add("Unit 3. Ferrous Metals :");
                    unitlist.add("Unit 4. Non Ferrous Metals:");
                    unitlist.add("Unit 5. Engineering Plastics and Fibers :");
                    unitlist.add("Unit 6. Insulating Materials :");
                    unitlist.add("Unit 7. Testing of Metals and Alloys :");
                    unitlist.add("Unit 8. Fundamentals of Heat Treatment :");
                    unitlist.add("Unit 9. Welding Process :");
                    unitlist.add("Unit 10. Gas Welding :");
                    unitlist.add("Unit 11. Electric Arc Welding :");
                    unitlist.add("Unit 12. Other Welding Processes :");
                    unitlist.add("Unit 13. Modern Welding Methods :");
                    unitlist.add("Unit 14. Foundry :");
                }
                else if (item4.matches("ME 204 Theory Of Machines"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Simple Mechanism:");
                    unitlist.add("Unit 2. Velocity and Acceleration in Mechanism:");
                    unitlist.add("Unit 3. Dynamics of Reciprocating Parts:");
                    unitlist.add("Unit 4. Friction:");
                    unitlist.add("Unit 5. Transmission of Power:");
                    unitlist.add("Unit 6. Balancing:");
                    unitlist.add("Unit 7. Vibration:");
                    unitlist.add("Unit 8. Governors ( No derivation & numerical) :");
                    unitlist.add("Unit 9. Brakes and Dynamometer:");
                    unitlist.add("Unit 10. Gyroscope ? Introduction and principle, Gyroscopic couple");
                }
                else if (item4.matches("ME 205 Machine Drawing and Computer Aided Drafting"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Machining Symbols and Tolerances :");
                    unitlist.add("Unit 2. Working Drawing :");
                    unitlist.add("Unit 3. Assembly Drawing:");
                    unitlist.add("Unit 4.  Gear tooth profile");
                    unitlist.add("Unit 5. Cam profile");
                    unitlist.add("Unit 6. Computer Graphics");
                }
                else if (item4.matches("ME 206 Basic Automobile Engg."))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction:");
                    unitlist.add("Unit 2. Suspension System:");
                    unitlist.add("Unit 3. Braking Systems :");
                    unitlist.add("Unit 4. Wheels and Tyres :");
                    unitlist.add("Unit 5. Front axle and Steering System:");
                    unitlist.add("Unit 6. Power Transmission System :");
                    unitlist.add("Unit 7. Frame and Body:");
                }
                else if (item4.matches("ME 207 Electrical & Electronics Engg."))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. D.C. Machines:");
                    unitlist.add("Unit 2. Transformer:");
                    unitlist.add("Unit 3. Induction Motor:");
                    unitlist.add("Unit 4. Industrial Drives:");
                    unitlist.add("Unit 5. Electric Heating:");
                    unitlist.add("Unit 6. Illumination:");
                    unitlist.add("Unit 7. Instrumentation and Measurement:");
                    unitlist.add("Unit 8. Semiconductor and P-_x0005_ Junction Diode:");
                    unitlist.add("Unit 9. Bipolar Junction Transistor:");
                    unitlist.add("Unit 10. Digital Electronics:");
                    unitlist.add("Unit 11. Power Electronics:");
                    unitlist.add("Unit 12. Relays Contactors and Timers:");
                    unitlist.add("Unit 13. Photo Electric Devices:");
                }
                else if (item4.matches("ME 208 Thermodynamics & I.C. Engines"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Basic Concept and Gas Laws :");
                    unitlist.add("Unit 2. Laws of Thermodynamics:");
                    unitlist.add("Unit 3. Availability :");
                    unitlist.add("Unit 4. Formation of Steam and its Properties :");
                    unitlist.add("Unit 5. Steam Generators:");
                    unitlist.add("Unit 6. Boiler Performance:");
                    unitlist.add("Unit 7. Gas Power Cycles:");
                    unitlist.add("Unit 8. Principles of Internal Combustion Engines :");
                    unitlist.add("Unit 9. Petrol Engines :");
                    unitlist.add("Unit 10. Diesel Engines:");
                    unitlist.add("Unit 11. Cooling, Lubrication and Governing :");
                    unitlist.add("Unit 12. I.C. Engines Performance:");
                    unitlist.add("Unit 13. Gas Turbines (No numerical problem):");
                    unitlist.add("Unit 14. Air Compressors (No numerical problem):");
                }
                else if (item4.matches("ME 209 Workshop Technology & Metrology"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Cutting Tools and Materials:");
                    unitlist.add("Unit 2. Lathe Machine:");
                    unitlist.add("Unit 3. Drilling Machines :");
                    unitlist.add("Unit 4. Shaping, Planning and Slotting Machines:");
                    unitlist.add("Unit 5. Cutting Fluids and Cooling Process:");
                    unitlist.add("Unit 6. Introduction to Metrology:");
                    unitlist.add("Unit 7. Linear and Angular Measurement:");
                    unitlist.add("Unit 8. Measurement of Surface Finish :");
                    unitlist.add("Unit 9. Comparators:");
                    unitlist.add("Unit 10. Light Wave Interference:");
                    unitlist.add("Unit 11. Gear and Screw Measurement:");
                    unitlist.add("Unit 12. Limits, Fits and Tolerance:");
                    unitlist.add("Unit 13. Machine Tool Metrology:");
                }
                else if (item4.matches("ME 210 C Programming"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction :");
                    unitlist.add("Unit 2. Elements of 'C' :");
                    unitlist.add("Unit 3. Console Input-Output :");
                    unitlist.add("Unit 4. Control Flow :");
                    unitlist.add("Unit  5. Arrays :");
                    unitlist.add("Unit 6. Functions :");
                    unitlist.add("Unit 7. Pointers :");
                    unitlist.add("Unit 8. Structure and Enumerated Data Types :");
                }
                else if (item4.matches("ME 301 Refrigeration and Air Conditioning"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Principles of Refrigeration :");
                    unitlist.add("Unit 2. Refrigeration System :");
                    unitlist.add("Unit 3.  Refrigerants:");
                    unitlist.add("Unit 4.  Refrigeration System, Components and Controls :");
                    unitlist.add("Unit 5.  Refrigeration Applications :");
                    unitlist.add("Unit 6. Production of Low Temperature :");
                    unitlist.add("Unit 7. Pshychrometry :");
                    unitlist.add("Unit 8. Air-conditioning :");
                }
                else if (item4.matches("ME 302 Processes In Manufacturing"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Metal Forming Process :");
                    unitlist.add("Unit 2. Conventional Metal Cutting Processes :");
                    unitlist.add("Unit 3. Newer Machining Processes :");
                    unitlist.add("Unit 4. Metallic Coating Processes :");
                    unitlist.add("Unit 5. Plastic Process - Working principle, Advantages and limitation of following process :");
                    unitlist.add("Unit 6. Jigs and Fixtures :");
                }
                else if (item4.matches("ME 303 Thermal Engineering & Heat Transfer"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Steam Nozzles :");
                    unitlist.add("Unit 2. Steam Turbines :");
                    unitlist.add("Unit 3. Steam Condenser :");
                    unitlist.add("Unit 4. Air Pumps and Cooling Tower :");
                    unitlist.add("Unit 5. Heat Transfer :");
                    unitlist.add("Unit 6. Conduction :");
                    unitlist.add("Unit 7. Convection :");
                    unitlist.add("Unit 8. Radiation :");
                }
                else if (item4.matches("ME 304 CNC Machines & Automation"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction :");
                    unitlist.add("Unit 2. Component of NC Machines :");
                    unitlist.add("Unit 3. Classification of Numerical Control Machines :");
                    unitlist.add("Unit 4. Constructional Details of CNC Machines :");
                    unitlist.add("Unit 5. Tooling for CNC Machines :");
                    unitlist.add("Unit 6. Fundamentals of Part Programming :");
                    unitlist.add("Unit 7. Advanced Part Programming :");
                    unitlist.add("Unit 8. Computer Aided Part Programming :");
                    unitlist.add("Unit 9. Robotics :");
                    unitlist.add("Unit 10. Automation in Manufacturing :");
                }
                else if (item4.matches("ME 305 Power Generation"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction :");
                    unitlist.add("Unit 2. Thermal Power Plants :");
                    unitlist.add("Unit 3. Hydro-Electric Power Plant :");
                    unitlist.add("Unit 4. Nuclear Power Plant :");
                    unitlist.add("Unit 5. Diesel Power Plants :");
                    unitlist.add("Unit 6. Gas Turbine Plants :");
                    unitlist.add("Unit 7. Power Plant Economics :");
                    unitlist.add("Unit 8. Renwal Energy Sources :");
                    unitlist.add("Unit 9. Solar Energy :");
                    unitlist.add("Unit 10. Wind Energy :");
                }
                else if (item4.matches("ME 306 Advance Workshop Techniques"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Metal Cutting Saws :");
                    unitlist.add("Unit 2. Boring :");
                    unitlist.add("Unit 3. Milling Machine :");
                    unitlist.add("Unit 4. Grinding and Grinding Machines :");
                    unitlist.add("Unit 5. Capstan and Turret Lathes :");
                    unitlist.add("Unit 6. Automatic Machines :");
                    unitlist.add("Unit 7. Metal Finishing Processes :");
                    unitlist.add("Unit 8. Maintenance of Machine Tools :");
                    unitlist.add("Unit 9. Installation and Testing of Machine Tools :");
                }
                else if (item4.matches("ME 307 Industrial Engineering"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Production, Planning and Control :");
                    unitlist.add("Unit 2. Inventory Control :");
                    unitlist.add("Unit 3. Inspection and Quality Control :");
                    unitlist.add("Unit 4. Work Study :");
                    unitlist.add("Unit 5. Plant Location and Layout :");
                    unitlist.add("Unit 6. Material Handling :");
                    unitlist.add("Unit 7. Linear Programming :");
                    unitlist.add("Unit 8. Depreciation :");
                }
                else if (item4.matches("ME 308 Machine Design"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction :");
                    unitlist.add("Unit 2. Design of Welding Joints :");
                    unitlist.add("Unit 3. Design of Screw and Bolts :");
                    unitlist.add("Unit 4. Design of Joints :");
                    unitlist.add("Unit 5. Design of Keys and Couplings :");
                    unitlist.add("Unit 6. Design of Shaft :");
                    unitlist.add("Unit 7. Design of Components :");
                    unitlist.add("Unit 8. Bearings (no numerical problems) :");
                    unitlist.add("Unit 9. Lever :");
                }
                else if (item4.matches("ME 309 Mechanical Estimating & Costing"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction :");
                    unitlist.add("Unit 2. Elements of Costs :");
                    unitlist.add("Unit 3. Break Even Analysis and Equipment Replacement Analysis :");
                    unitlist.add("Unit 4. Estimation of Material Cost :");
                    unitlist.add("Unit 5. Labour Costing :");
                    unitlist.add("Unit 6. Estimation in Machining :");
                    unitlist.add("Unit 7. Estimation in Welding Shop :");
                    unitlist.add("Unit 8. Estimation in Forging Shop :");
                    unitlist.add("Unit 9. Estimation in Pattern Making and Foundry Shop :");
                    unitlist.add("Unit 10. Estimation in Sheet Metal Shop :");
                }
                else if (item4.matches("ME 310 Management &Entrepreneurship"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Principles of Management :");
                    unitlist.add("Unit 2. Human Resources Development :");
                    unitlist.add("Unit 3. Wages and Incentives :");
                    unitlist.add("Unit 4. Material Management :");
                    unitlist.add("Unit 5. Financial Management :");
                    unitlist.add("Unit 6. Marketing Management :");
                    unitlist.add("Unit 7. Entrepreneurship :");
                    unitlist.add("Unit 8. Entrepreneurial Development :");
                    unitlist.add("Unit 9. Entrepreneurship Support System:");
                    unitlist.add("Unit 10. Setting up SSI :");
                    unitlist.add("Unit 11. Tax System and Insurance :");
                    unitlist.add("Unit 12. Financial Sources for SSI :");
                    unitlist.add("Unit 13. Labour Legislation and Pollution Control Acts :");
                    unitlist.add("Unit 14. Project Report :");
                    unitlist.add("Unit 15. ISO : 9000 Series of Quality System :");
                }
                else if (item4.matches("CS 201 PROGRAMMING AND PROBLEM SOLVING THROUGH 'C'"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction");
                    unitlist.add("Unit 2. Elements of ‘C’");
                    unitlist.add("Unit 3. Console Input-Output");
                    unitlist.add("Unit 4. Control Flow");
                    unitlist.add("Unit 5. Arrays");
                    unitlist.add("Unit 6. Functions");
                    unitlist.add("Unit 7. Pointers");
                    unitlist.add("Unit 8. Structure, Union and Enumerated Data Types");
                    unitlist.add("Unit 9. File Handling");
                    unitlist.add("Unit 10. Numerical Methods");
                }
                else if (item4.matches("CS 202 COMPUTER SYSTEM ARCHITECTURE"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Overview of Computer Organization");
                    unitlist.add("Unit 2. Register and Micro -Operations");
                    unitlist.add("Unit 3. Basic Computer Organization");
                    unitlist.add("Unit 4. Central Processor Organization");
                    unitlist.add("Unit 5. Arithmetic Processor Organization");
                    unitlist.add("Unit 6. Input / Output Organization");
                    unitlist.add("Unit 7. Memory Organization");
                    unitlist.add("Unit 8. Introduction to Parallel Processing");
                }
                else if (item4.matches("CS 203 OPERATING SYSTEM PRINCIPLE"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit  1. Introduction");
                    unitlist.add("Unit 2. Process Management and CPU Scheduling");
                    unitlist.add("Unit 3. Deadlocks");
                    unitlist.add("Unit 4. Memory Management");
                    unitlist.add("Unit 5. Virtual Memory");
                    unitlist.add("Unit 6. File System");
                    unitlist.add("Unit 7. Distributed Operating System (DOS)");
                }
                else if (item4.matches("CS 204 BASICS OF ELECTRONIC DEVICES AND CIRCUITS"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Semiconductor and PN Junction");
                    unitlist.add("Unit 2. Bipolar Junction Transistor (BJT)");
                    unitlist.add("Unit 3. Transistor Biasing and Bias Stability");
                    unitlist.add("Unit 4. Field Effect Transistor");
                    unitlist.add("Unit 5. Rectifiers");
                    unitlist.add("Unit 6. Power Supplies & Sensors");
                }
                else if (item4.matches("CS 205 Basics of Digital Electronics"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction");
                    unitlist.add("Unit 2. Number System");
                    unitlist.add("Unit 3. Logic Gates & Families");
                    unitlist.add("Unit 4. Boolean Algebra");
                    unitlist.add("Unit 5. Minimization Techniques ( K-Mapping)");
                    unitlist.add("Unit 6. Combinational Logic Design");
                    unitlist.add("Unit 7. Sequential Systems");
                    unitlist.add("");
                }
                else if (item4.matches("CS 206 Data Communication"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction");
                    unitlist.add("Unit 2. Signals and Transmission");
                    unitlist.add("Unit 3. Multiplexing and Communication Hardware");
                    unitlist.add("Unit 4. Data Link Layer");
                    unitlist.add("Unit 5. Switching and Frame Relay");
                }
                else if (item4.matches("CS 207 Data Base Management System"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Indroduction");
                    unitlist.add("Unit 2. Data Modeling Using the E-R Model");
                    unitlist.add("Unit 3. Relational Data Model and Language");
                    unitlist.add("Unit 4. Normalization");
                    unitlist.add("Unit 5. Transaction Processing Concepts");
                    unitlist.add("Unit 6. Deadlock Handling");
                    unitlist.add("Unit 7. Concurrency Control Techniques");
                }
                else if (item4.matches("CS 208 Microprocessor and Interfacing"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction");
                    unitlist.add("Unit 2. The 8085 Architecture");
                    unitlist.add("Unit 3. 8085 Instructions and Programming");
                    unitlist.add("Unit 4. Memory and I/O System");
                    unitlist.add("Unit 5. Instruction Execution and Timings");
                    unitlist.add("Unit 6. Interfacing With 8085");
                    unitlist.add("Unit 7. Introduction to x 86 Family (8086)");
                }
                else if (item4.matches("CS 209 Internet and Web Technologies"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Internet Basics");
                    unitlist.add("Unit 2. HTML");
                    unitlist.add("Unit 3. Java Script");
                    unitlist.add("Unit 4. DHTML");
                    unitlist.add("Unit 5. CGI");
                    unitlist.add("Unit 6. Perl");
                }
                else if (item4.matches("CS 210 PC Maintenance and Trouble Shooting"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Computer Installation");
                    unitlist.add("Unit 2. Safety and Security Measures");
                    unitlist.add("Unit 3. Working Principles of peripheral devices");
                    unitlist.add("Unit 4. Display Technologies-Thin Displays");
                    unitlist.add("Unit 5. Optical Storage Devices");
                    unitlist.add("Unit 6. I/O Ports");
                    unitlist.add("Unit 7. Hard Disk Drive (HDD)");
                    unitlist.add("Unit 8. Windows Components and Tools");
                    unitlist.add("Unit 9. Memory");
                }
                else if (item4.matches("CS 301 Data Structure & Algorithm"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1 Introduction to Data Structures and Algorithms :");
                    unitlist.add("Unit 2 Algorithm on Linked List :");
                    unitlist.add("Unit 3 Algorithms on Stack :");
                    unitlist.add("Unit 4. Algorithms on Queue :");
                    unitlist.add("Unit 5 Non-Linear Data Structure: Tree");
                    unitlist.add("Unit 6 Non-Linear Data Structure: Graph :");
                    unitlist.add("Unit 7 Sorting and Searching Algorithms and their Analysis");
                }
                else if (item4.matches("CS 302 Object Oriented Programming Through C++"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. An Overview of Object Oriented Programming :");
                    unitlist.add("Unit 2. Object Oriented Programming Using C++ :");
                    unitlist.add("Unit 3. Objects and Classes :");
                    unitlist.add("Unit 4. Overloading of Functions and Operators :");
                    unitlist.add("Unit 5. Inheritance and Polymorphism :");
                    unitlist.add("Unit 6. Templates and Exception Handling :");
                    unitlist.add("Unit 7. Managing Console I/O and File I/O :");
                }
                else if (item4.matches("CS 303 Unix, Shell Programming and Administration"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. UNIX An Introduction :");
                    unitlist.add("Unit 2. File System :");
                    unitlist.add("Unit 3. UNIX Commands :");
                    unitlist.add("Unit 4. vi Editor :");
                    unitlist.add("Unit 5. UNIX Shell :");
                    unitlist.add("Unit 6. Shell Programming :");
                    unitlist.add("Unit 7. Essential System Administration :");
                }
                else if (item4.matches("CS 304 Software Engineering"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction :");
                    unitlist.add("Unit 2. Software Life Cycle Models :");
                    unitlist.add("Unit 3. Requirement Analysis and Specification");
                    unitlist.add("Unit 4. Software Design :");
                    unitlist.add("Unit 5. Function Oriented Design");
                    unitlist.add("Unit 6. Software Testing :");
                    unitlist.add("Unit 7. Software Reliability and Quality Management :");
                }
                else if (item4.matches("CS 305 Dot Net Technology"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Introduction to NET Framework and Development Environment :");
                    unitlist.add("Unit 2. Visual Basic.NET :");
                    unitlist.add("Unit 3. Programming Concepts of VB.NET :");
                    unitlist.add("Unit 4. Object Oriented Features of VB.NET :");
                    unitlist.add("Unit 5. Windows FORMS and Controls");
                    unitlist.add("Unit 6. Database Connectivity using ADO.NET :");
                    unitlist.add("Unit 7. ASP.NET :");
                }
                else if (item4.matches("CS 306 Computer Network"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Data Link Layer and Local Area Networks :");
                    unitlist.add("Unit 2 Network Layer and Routing :");
                    unitlist.add("Unit 3. Transport Layer :");
                    unitlist.add("Unit 4. Application Layer :");
                    unitlist.add("Unit 5. Wireless Networking :");
                }
                else if (item4.matches("CS 307 Data warehouse and mining"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1 Data Mining :");
                    unitlist.add("Unit 2. Data Pre-Processing :");
                    unitlist.add("Unit 3. Data Mining Techniques :");
                    unitlist.add("Unit 4. Data Warehouse :");
                    unitlist.add("Unit 5. Data Warehouse Architecture :");
                    unitlist.add("Unit 6. Components of Data Warehouse :");
                    unitlist.add("Unit 7. On-Line Analytical Processing :");
                }
                else if (item4.matches("CS 308 Introduction to Network Security and Cryptography"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Computer Security :");
                    unitlist.add("Unit 2. Attacks on Computer :");
                    unitlist.add("Unit 3. Cryptographic : Concepts and Techniques");
                    unitlist.add("Unit 4. Symmetric and Asymmetric Key Cryptography");
                    unitlist.add("Unit 5. Internet Security Protocols");
                    unitlist.add("Unit 6. E-mail Security:");
                    unitlist.add("Unit 7.Firewall");
                }
                else if (item4.matches("CS 309 Java Tools"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Java Fundamentals :");
                    unitlist.add("Unit 2. Applet :");
                    unitlist.add("Unit 3. Graphics :");
                    unitlist.add("Unit 4. AWT and Event Handling:");
                    unitlist.add("Unit 5. Swing :");
                    unitlist.add("Unit 6. JDBC :");
                    unitlist.add("Unit 7. Servlet :");
                }
                else if (item4.matches("CS 310 PHP & MySql"))
                {
                    spinner5.setEnabled(true);
                    //branchlist.clear();
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                    unitlist.add("Unit 1. Overview of PHP :");
                    unitlist.add("Unit 2. Basic Scripting, Loop and Conditional Constructs");
                    unitlist.add("Unit 3. Arrays in PHP :");
                    unitlist.add("Unit 4. Working with Databases and Forms");
                    unitlist.add("Unit 5. Using Cookies with PHP :");
                    unitlist.add("Unit 6. MySQL :");
                }
                else
                {
                    spinner5.setEnabled(false);
                    unitlist.clear();
                    unitlist.add("Select Unit");
                    fifthAdapter.notifyDataSetChanged();
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        spinner4.setAdapter(forthAdapter);


        unitlist.add("Select Unit");
        spinner5.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                               @Override
                                               public void onItemSelected(AdapterView<?> parent5, View view, int position, long id) {
                                                   item5 = parent5.getItemAtPosition(position).toString();
                                                   if((unitlist.contains(""+item5)) && !item5.matches("Select Unit"))
                                                   {
                                                       btnSearch.setEnabled(true);
                                                   }
                                                   else
                                                   {
                                                       //spinner5.setEnabled(true);
                                                       fifthAdapter.notifyDataSetChanged();
                                                       btnSearch.setEnabled(false);
                                                   }
                                               }

                                               @Override
                                               public void onNothingSelected(AdapterView<?> parent) {

                                               }
                                           });
        fifthAdapter.setDropDownViewResource(android.R.layout.simple_list_item_activated_1);
        spinner5.setAdapter(fifthAdapter);


        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(view.getContext(), MainActivity2.class);
                intent.putExtra("course",item1);
                intent.putExtra("year",item2);
                intent.putExtra("branch",item3);
                intent.putExtra("subcode",item4);
                intent.putExtra("unit",item5);
                view.getContext().startActivity(intent);
            }
        });

    }

    private void showVideo() {
       String URL="http://192.168.43.23/admin/User_api/tcc?token_key=AaShTaK@2020@WaterSupplY&subcode=EL201/EF%20201&pointno=1.1";

        RequestQueue requestQueue= Volley.newRequestQueue(getApplicationContext());
        StringRequest stringRequest=new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    JSONArray jsonArray=jsonObject.getJSONArray("Data");
                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        String jsonVideoId=jsonObject1.getString("ItemId");
                       // Log.e(TAG,"video ID"+jsonVideoId);
                        //  String videoid=jsonVideoId.getString("kind");
                        //  JSONObject jsonsnippet= jsonObject1.getJSONObject("snippet");
                        //JSONObject jsonObjectdefault = jsonsnippet.getJSONObject("thumbnails").getJSONObject("default");
                        String Topic=jsonObject1.getString("Topic");
                        String Unit=jsonObject1.getString("Unit");


                        VideoDetails videoDetails=new VideoDetails();

                        // String videoid=jsonVideoId.getString("kind");
                        //Log.e(TAG," New Video Id" +videoid);
/*
                        videoDetails.setURL("url");
                        videoDetails.setVideoName(Topic);
                        videoDetails.setVideoDesc(Unit);

                        videoDetails.setVideoId(jsonVideoId);

                        videoDetailsArrayList.add(videoDetails);

 */
                        heroList.add(new Hero(Topic,jsonVideoId , Unit));


//                         videoDetailsArrayList.clear();


                    }
                    lvVideo.setAdapter(customListAdapter);

                    customListAdapter.notifyDataSetChanged();
                    // lvVideo.setAdapter(null);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        int socketTimeout = 30000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(policy);
        requestQueue.add(stringRequest);

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        if (id == R.id.home) {
            startActivity(new Intent(electure.this, MainActivity.class));
            return true;
        }
        if (id == R.id.important_link) {
            startActivity(new Intent(electure.this,imp_link.class));
            return true;
        }
        if (id == R.id.Syllabus) {
            startActivity(new Intent(electure.this,syllabus.class));
            return true;
        }
        if (id == R.id.feedback_Suggestion) {
            url = "https://docs.google.com/forms/d/e/1FAIpQLSdH0e-9UScRXX7-VbkF4G-ZMOGSVOZdknnvDmw3256VsEQwTg/viewform?usp=sf_link";
            title = "Feedback & Suggestions";
            Intent web = new Intent(electure.this,WebViewActivity.class);
            web.putExtra("url",url);
            web.putExtra("title",title);
            startActivity(web);
        }
        if (id == R.id.exit) {
            new AlertDialog.Builder(this)
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .setTitle("Closing Activity")
                    .setMessage("Are you sure you want to close this activity?")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener()
                    {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }

                    })
                    .setNegativeButton("No", null)
                    .show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}