package com.example.polytechnicshiksha;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;

public class MainActivity2 extends AppCompatActivity {
    String item;
    List<Hero> heroList;
    List<String> categories = new ArrayList<String>();
    List<String> branchlist = new ArrayList<>();
    EditText etSearch;
    Button btnSearch;
    ListView lvVideo;
    ArrayList<VideoDetails> videoDetailsArrayList;
    MyListAdapter customListAdapter;

    String searchName;
    String course ;
    String year ;
    String branch ;
    String subcode ;
    String unit ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        lvVideo=(ListView)findViewById(R.id.videoList);
        heroList = new ArrayList<>();
        Bundle bundle = getIntent().getExtras();
         course = bundle.getString("course");
         year = bundle.getString("year");
         branch = bundle.getString("branch");
         //branch=branch.trim();
       // branch=branch.replaceAll("\\s", "");
        subcode = bundle.getString("subcode");
        unit=bundle.getString("unit");
        Log.e("----->",unit);


        customListAdapter = new MyListAdapter(this, R.layout.my_custom_list, heroList);

        //attaching adapter to the listview
        lvVideo.setAdapter(customListAdapter);

        //attaching adapter to the listview
        // listView.setAdapter(adapter);


        //   lvVideo.setAdapter(adapter);

        customListAdapter.notifyDataSetChanged();
        enviarPost(true);
    }
    private void showVideo() {
        //String URL="https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&q="+searchName+"&key=AIzaSyAoRYyYO2OwNU2MZhYHcltkbGoGoTqXR5g";

        // String URL="http://192.168.43.95/admin/User_api/tcc?token_key=AaShTaK@2020@WaterSupplY&subcode="+subcode+"&branch="+branch+"&year="+year+"&course="+course;
        //String URL="http://192.168.43.95/admin/User_api/tcc";
/*
        try {
            RequestQueue requestQueue = Volley.newRequestQueue(this);
          //  String URL = "http://...";
            String URL="http://192.168.43.95/admin/User_api/tcc";
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("branch", branch);
            jsonBody.put("subcode", subcode);
            jsonBody.put("token_key", "AaShTaK@2020@WaterSupplY");


            final String requestBody = jsonBody.toString();

            StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                  Log.e("res",response.toString());
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            JSONArray jsonArray=jsonObject.getJSONArray("Data");
                            for(int i=0;i<jsonArray.length();i++){
                                JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                String jsonVideoId=jsonObject1.getString("ItemId");
                                // Log.e(TAG,"video ID"+jsonVideoId);
                                //  String videoid=jsonVideoId.getString("kind");
                                //  JSONObject jsonsnippet= jsonObject1.getJSONObject("snippet");
                                //JSONObject jsonObjectdefault = jsonsnippet.getJSONObject("thumbnails").getJSONObject("default");
                                String Topic=jsonObject1.getString("Topic");
                                String Unit=jsonObject1.getString("Unit");


                                VideoDetails videoDetails=new VideoDetails();

                                // String videoid=jsonVideoId.getString("kind");
                                //Log.e(TAG," New Video Id" +videoid);
/*
                        videoDetails.setURL("url");
                        videoDetails.setVideoName(Topic);
                        videoDetails.setVideoDesc(Unit);

                        videoDetails.setVideoId(jsonVideoId);

                        videoDetailsArrayList.add(videoDetails);


                                heroList.add(new Hero(Topic,jsonVideoId , Unit));


//                         videoDetailsArrayList.clear();


                            }
                            lvVideo.setAdapter(customListAdapter);

                            customListAdapter.notifyDataSetChanged();
                            // lvVideo.setAdapter(null);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e("VOLLEY", error.toString());
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }

                @Override
                public byte[] getBody()  {
                    try {
                        return requestBody == null ? null : requestBody.getBytes("utf-8");
                    } catch (UnsupportedEncodingException uee) {
                        VolleyLog.wtf("Unsupported Encoding while trying to get the bytes of %s using %s", requestBody, "utf-8");
                        return null;
                    }
                }

                @Override
                protected Response<String> parseNetworkResponse(NetworkResponse response) {
                    String responseString = "";
                    if (response != null) {
                        responseString = String.valueOf(response.statusCode);
                        // can get more details such as response.headers
                    }
                    return Response.success(responseString, HttpHeaderParser.parseCacheHeaders(response));
                }
            };

            requestQueue.add(stringRequest);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        */
        String URL="http://34.238.231.153/admin/User_api/tcc";
        JSONObject postData = new JSONObject();
        try {
            postData.put("branch", branch);
            postData.put("subcode", subcode);
            postData.put("token_key", "AaShTaK@2020@WaterSupplY");

        } catch (JSONException e) {
            e.printStackTrace();
        }
        RequestQueue requestQueue= Volley.newRequestQueue(getApplicationContext());
        JsonObjectRequest JsonObjectRequest=new JsonObjectRequest(Request.Method.POST, URL,postData, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject  response) {
                try {
                    Log.e(response.toString(),"sas");
                    JSONObject jsonObject=response;
                    JSONArray jsonArray=jsonObject.getJSONArray("Data");
                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        String jsonVideoId=jsonObject1.getString("ItemId");
                        // Log.e(TAG,"video ID"+jsonVideoId);
                        //  String videoid=jsonVideoId.getString("kind");
                        //  JSONObject jsonsnippet= jsonObject1.getJSONObject("snippet");
                        //JSONObject jsonObjectdefault = jsonsnippet.getJSONObject("thumbnails").getJSONObject("default");
                        String Topic=jsonObject1.getString("Topic");
                        String Unit=jsonObject1.getString("Unit");


          //              VideoDetails videoDetails=new VideoDetails();

                        // String videoid=jsonVideoId.getString("kind");
                        //Log.e(TAG," New Video Id" +videoid);
/*
                        videoDetails.setURL("url");
                        videoDetails.setVideoName(Topic);
                        videoDetails.setVideoDesc(Unit);

                        videoDetails.setVideoId(jsonVideoId);

                        videoDetailsArrayList.add(videoDetails);

 */



                        heroList.add(new Hero(Topic,jsonVideoId , Unit));


//                         videoDetailsArrayList.clear();


                    }
                    lvVideo.setAdapter(customListAdapter);

                    customListAdapter.notifyDataSetChanged();
                    // lvVideo.setAdapter(null);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }

        }) ;


        int socketTimeout = 30000;
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        JsonObjectRequest.setRetryPolicy(policy);
        requestQueue.add(JsonObjectRequest);

    }

    private void enviarPost(boolean modo) {
        String URL="http://34.238.231.153/admin/User_api/tcc";

        AsyncHttpClient clientSendPost = new AsyncHttpClient();
        RequestParams requestParams = new RequestParams();
        String mode = !modo ? "GET" : "POST";
        ArrayList<String> itemsList = new ArrayList<>();
        itemsList.add("a");
        itemsList.add("b");
        requestParams.put("branch", branch);
        requestParams.put("subcode", subcode);
        requestParams.put("token_key", "AaShTaK@2020@WaterSupplY");
        requestParams.put("unit", unit);

        // requestParams.put("token_key", "AaShTaK@2020@WaterSupplY");
        clientSendPost.post(URL, requestParams, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                if (statusCode == 200) { // I think success means always code 200
                    String res = null;
                    try {
                        res = new String(responseBody, "UTF-8");
                        Log.e("----->",res);
                        JSONObject jsonObject=new JSONObject(res);
                        JSONArray jsonArray=jsonObject.getJSONArray("Data");
                        for(int i=0;i<jsonArray.length();i++){
                            ArrayList<String> jsonVideoId=new ArrayList<>();
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                           for(int j=0;j<30;j++)
                           {
                               jsonVideoId.add(jsonObject1.getString("ItemId"+j));
                           }
                             // Log.e(TAG,"video ID"+jsonVideoId);
                            //  String videoid=jsonVideoId.getString("kind");
                            //  JSONObject jsonsnippet= jsonObject1.getJSONObject("snippet");
                            //JSONObject jsonObjectdefault = jsonsnippet.getJSONObject("thumbnails").getJSONObject("default");
                            String Topic=jsonObject1.getString("Topic");
                            String Unit=jsonObject1.getString("Unit");


                            //              VideoDetails videoDetails=new VideoDetails();

                            // String videoid=jsonVideoId.getString("kind");
                            //Log.e(TAG," New Video Id" +videoid);
/*
                        videoDetails.setURL("url");
                        videoDetails.setVideoName(Topic);
                        videoDetails.setVideoDesc(Unit);

                        videoDetails.setVideoId(jsonVideoId);

                        videoDetailsArrayList.add(videoDetails);

 */


                       for(int k=0;k<30;k++) {
                           if(!jsonVideoId.get(k).isEmpty()) {
                               heroList.add(new Hero(Topic, jsonVideoId.get(k), Unit));
                           }
                       }

//                         videoDetailsArrayList.clear();


                        }

                        lvVideo.setAdapter(customListAdapter);
                        ProgressBar p1=findViewById(R.id.p1);
                        p1.setVisibility(View.INVISIBLE);
                        customListAdapter.notifyDataSetChanged();

                      //  Log.e("app", res);
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    catch (JSONException e) {
                        e.printStackTrace();
                    }

                    Toast.makeText(getBaseContext(), "success data from server", Toast.LENGTH_SHORT)
                            .show();

                    // PopulateListView(ParserJSON(res));
                }

                Log.i("app", responseBody.toString());

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Toast.makeText(getBaseContext(), "Error getting data from server", Toast.LENGTH_SHORT)
                        .show();

                Log.e("app", "User could not be created");
            }
        });
    }

}